const https = require('https');
const xml2js = require('xml2js');

exports.handler = async (event) => {
  const url = 'https://openapi.gg.go.kr/GGNEWSSTUS'; // XML 타입의 응답을 요청

  return new Promise((resolve, reject) => {
    https.get(url, (res) => {
      let data = '';

      res.on('data', (chunk) => {
        data += chunk;
      });

      res.on('end', () => {
        xml2js.parseString(data, (error, result) => {
          if (error) {
            reject({
              statusCode: 500,
              body: JSON.stringify({ error: 'Error parsing XML data' }),
            });
          } else {
            // XML을 JSON으로 변환한 데이터 처리
            const announcements = result.GGNEWSSTUS[1].row.slice(0, 9);
            resolve({
              statusCode: 200,
              headers: {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*' // CORS 허용
              },
              body: JSON.stringify(announcements)
            });
          }
        });
      });
    }).on('error', (e) => {
      reject({
        statusCode: 500,
        body: JSON.stringify(e)
      });
    });
  });
};
